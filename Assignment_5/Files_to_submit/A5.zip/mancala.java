import java.io.*;
import java.util.Scanner;

public class mancala {
    public static void main(String[] args) {
        /**
         * choosing not to do the Mancala question
         */
        int x = 5;
    }
}